
import { cn } from "@/lib/utils";

const Footer = () => {
  return (
    <footer className="bg-muted mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <a href="/" className="inline-block mb-4">
              <div className="flex items-center">
                <span className="text-maroon text-2xl font-bold">தமிழ்</span>
                <span className="text-earthBrown text-xl ml-1 font-medium">கதைகள்</span>
              </div>
            </a>
            <p className="text-muted-foreground max-w-md">
              அனைத்து வயதினருக்கும் ஏற்ற தமிழ் கதைகளை வழங்கும் தளம். கட்டுரைகள், கவிதைகள், சிறுகதைகள் மற்றும் பல.
            </p>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">பிரிவுகள்</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  காதல் கதைகள்
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  வரலாற்று கதைகள்
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  குடும்ப கதைகள்
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  வீர கதைகள்
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">தொடர்பு</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  எங்களைப் பற்றி
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  தொடர்பு கொள்ள
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  அடிக்கடி கேட்கப்படும் கேள்விகள்
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  உதவி
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className={cn(
          "mt-12 pt-6 border-t border-border",
          "flex flex-col md:flex-row justify-between items-center"
        )}>
          <p className="text-muted-foreground text-sm mb-4 md:mb-0">
            &copy; 2024 தமிழ் கதைகள். அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              பயன்பாட்டு விதிமுறைகள்
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              தனியுரிமைக் கொள்கை
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import { Story } from "@/data/stories";
import { Button } from "@/components/ui/button";
import { BookOpen } from "lucide-react";

interface FeaturedStoryProps {
  story: Story;
}

const FeaturedStory = ({ story }: FeaturedStoryProps) => {
  return (
    <div className="relative h-[400px] md:h-[500px] overflow-hidden rounded-xl">
      <div 
        className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/10 z-10"
      />
      <div 
        className="absolute inset-0 bg-center bg-cover tamil-pattern opacity-20"
        style={{ backgroundImage: `url(${story.imageUrl})` }}
      />
      <div className="relative z-20 h-full flex flex-col justify-end p-6 md:p-8 lg:p-10">
        <div className="mb-2">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm">
            {story.category}
          </span>
          <span className="ml-3 text-white/80 text-sm">
            {story.date}
          </span>
        </div>
        <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-3">
          {story.title}
        </h2>
        <p className="text-white/90 mb-4 max-w-2xl text-sm md:text-base">
          {story.preview}
        </p>
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 bg-gray-300 rounded-full mr-3"></div>
          <span className="text-white font-medium">
            {story.author}
          </span>
        </div>
        <Button className="bg-white text-primary hover:bg-white/90 flex items-center w-fit">
          <BookOpen className="mr-2 h-4 w-4" />
          தொடர்ந்து படிக்க
        </Button>
      </div>
    </div>
  );
};

export default FeaturedStory;

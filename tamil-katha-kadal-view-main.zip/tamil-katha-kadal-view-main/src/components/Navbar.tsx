
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="relative bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <span className="text-maroon text-2xl font-bold">தமிழ்</span>
              <span className="text-earthBrown text-xl ml-1 font-medium">கதைகள்</span>
            </a>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-6">
            <a 
              href="/" 
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              முகப்பு
            </a>
            <a 
              href="#categories" 
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              வகைகள்
            </a>
            <a 
              href="#latest" 
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              புதியவை
            </a>
            <Button className="bg-primary text-white">
              உள்நுழைய
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-gray-700 hover:text-primary focus:outline-none"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "absolute top-full left-0 right-0 bg-white z-20 shadow-md transition-all duration-300 ease-in-out md:hidden",
          isMenuOpen ? "max-h-64 opacity-100" : "max-h-0 opacity-0 invisible"
        )}
      >
        <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <a 
            href="/" 
            className="text-foreground hover:text-primary transition-colors py-2 font-medium"
            onClick={toggleMenu}
          >
            முகப்பு
          </a>
          <a 
            href="#categories" 
            className="text-foreground hover:text-primary transition-colors py-2 font-medium"
            onClick={toggleMenu}
          >
            வகைகள்
          </a>
          <a 
            href="#latest" 
            className="text-foreground hover:text-primary transition-colors py-2 font-medium"
            onClick={toggleMenu}
          >
            புதியவை
          </a>
          <Button className="bg-primary text-white w-full">
            உள்நுழைய
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

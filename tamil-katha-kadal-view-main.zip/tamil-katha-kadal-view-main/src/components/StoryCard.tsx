
import { Story } from "@/data/stories";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { CalendarIcon } from "lucide-react";

interface StoryCardProps {
  story: Story;
}

const StoryCard = ({ story }: StoryCardProps) => {
  return (
    <Card className="h-full flex flex-col overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative h-48 overflow-hidden">
        <div 
          className="absolute inset-0 bg-center bg-cover tamil-pattern"
          style={{ backgroundImage: `url(${story.imageUrl})` }}
        />
        <div className="absolute top-2 right-2">
          <span className="bg-primary/90 text-white text-xs px-2 py-1 rounded-full">
            {story.category}
          </span>
        </div>
      </div>
      <CardHeader>
        <h3 className="font-bold text-lg line-clamp-2">{story.title}</h3>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-muted-foreground text-sm line-clamp-3">
          {story.preview}
        </p>
      </CardContent>
      <CardFooter className="pt-3 border-t flex items-center justify-between">
        <div className="flex items-center">
          <Avatar className="h-7 w-7 mr-2">
            <AvatarFallback className="bg-secondary/30 text-secondary-foreground text-xs">
              {story.author.substring(0, 2)}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">{story.author}</span>
        </div>
        <div className="flex items-center text-muted-foreground text-xs">
          <CalendarIcon className="h-3 w-3 mr-1" />
          {story.date}
        </div>
      </CardFooter>
    </Card>
  );
};

export default StoryCard;

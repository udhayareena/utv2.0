
import React from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FeaturedStory from "@/components/FeaturedStory";
import StoryCard from "@/components/StoryCard";
import NewStoryCard from "@/components/NewStoryCard";
import { Button } from "@/components/ui/button";
import { 
  categories, 
  getFeaturedStories, 
  getLatestStories, 
  getStoriesByCategory,
  getNewStories
} from "@/data/stories";
import { ChevronRight, BookOpen, Sparkles } from "lucide-react";

const Index = () => {
  const featuredStories = getFeaturedStories();
  const latestStories = getLatestStories(6);
  const newStories = getNewStories();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mt-8">
          {featuredStories.length > 0 && (
            <FeaturedStory story={featuredStories[0]} />
          )}
        </section>

        {/* New Stories Section */}
        {newStories.length > 0 && (
          <section className="container mx-auto px-4 mt-16" id="new-stories">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <h2 className="text-2xl font-bold">புதிய கதைகள்</h2>
                <span className="ml-2 inline-flex">
                  <Sparkles className="h-5 w-5 text-secondary animate-pulse" />
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {newStories.map((story) => (
                <NewStoryCard key={story.id} story={story} />
              ))}
            </div>
          </section>
        )}

        {/* Categories Section */}
        <section className="container mx-auto px-4 mt-16" id="categories">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">வகைகள்</h2>
            <Button variant="link" className="text-primary flex items-center">
              அனைத்தையும் காண்க <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {categories.map((category, index) => (
              <div 
                key={index}
                className="bg-accent rounded-lg p-4 text-center hover:bg-accent/80 transition-colors cursor-pointer"
              >
                <h3 className="font-medium">{category}</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  {getStoriesByCategory(category).length} கதைகள்
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Latest Stories Section */}
        <section className="container mx-auto px-4 mt-16" id="latest">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">சமீபத்திய கதைகள்</h2>
            <Button variant="link" className="text-primary flex items-center">
              அனைத்தையும் காண்க <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestStories.map((story) => (
              <StoryCard key={story.id} story={story} />
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-4 mt-16">
          <div className="relative rounded-xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-maroon/90 to-earthBrown/90 z-10" />
            <div className="absolute inset-0 tamil-pattern opacity-10" />
            <div className="relative z-20 py-12 px-6 md:p-12 text-white text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">உங்கள் கதைகளை பகிரவும்</h2>
              <p className="max-w-2xl mx-auto mb-6">
                உங்கள் படைப்புகளை எங்களுடன் பகிர்ந்து கொள்ளுங்கள். தமிழ் இலக்கியத்தை வளர்க்க உதவுங்கள்.
              </p>
              <Button className="bg-white text-primary hover:bg-white/90">
                <BookOpen className="mr-2 h-4 w-4" />
                கதை எழுத தொடங்கு
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
